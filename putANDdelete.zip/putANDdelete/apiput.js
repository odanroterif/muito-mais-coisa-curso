const axios = require('axios');
const url = "https://jsonplaceholder.typicode.com/posts/1";
//PUT-----------------------
//atom theme icons and code editor icons
axios.put( 
    url,
    {
        "title": "foo",
        "body": "bar",
        "userId": 1
        }                               
)
.then(response => {
    console.log("atualização realizada com sucesso");
    console.log(response.data);    
    })
    .catch(error => {
        console.error(error);
        });        