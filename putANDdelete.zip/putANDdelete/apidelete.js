const axios = require('axios');
const url = "https://jsonplaceholder.typicode.com/posts/1";
//DELETE--------------------
//atom theme icons and code editor icons
axios.delete(url, {
        })
        .then(response => {
            console.log("dados deletados");            
            console.log(response.data);  
            console.log(response.status);
            })
            .catch(error => {
                console.error(error);                
                });        