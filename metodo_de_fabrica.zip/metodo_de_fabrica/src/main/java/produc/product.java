package produc;



public abstract class product 
{
    public abstract void display();
}