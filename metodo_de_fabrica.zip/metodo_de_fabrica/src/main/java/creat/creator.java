package creat;

import produc.product;


public abstract class creator 
{
    public abstract product factoryMethod();
}
