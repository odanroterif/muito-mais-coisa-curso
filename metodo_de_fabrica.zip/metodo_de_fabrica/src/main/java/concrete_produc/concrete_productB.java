package concrete_produc;

import produc.product;

// Concrete Products
public class concrete_productB extends product 
{
    @Override
    public void display()
    {
	System.out.println("produto B fabricado.");
    }
}
