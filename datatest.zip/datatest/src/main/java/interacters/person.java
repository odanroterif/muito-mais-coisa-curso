
package interacters;


public class person 
{
    private String name;
    private String mom_name;
    private String dad_name;
    private String cpf;
    private int age;
    private float height;

 
    public String getName() 
    {
        return name;
    }

  
    public void setName(String name)
    {
        this.name = name;
    }

   
    public String getMom_name() 
    {
        return mom_name;
    }

  
    public void setMom_name(String mom_name) 
    {
        this.mom_name = mom_name;
    }

    
    public String getDad_name() 
    {
        return dad_name;
    }

    
    public void setDad_name(String dad_name) 
    {
        this.dad_name = dad_name;
    }

   
    public String getCpf() 
    {
        return cpf;
    }

   
    public void setCpf(String cpf) 
    {
        this.cpf = cpf;
    }

    
    public int getAge()
    {
        return age;
    }

   
    public void setAge(int age) 
    {
        this.age = age;
    }

    
    public float getHeight() 
    {
        return height;
    }

   
    public void setHeight(float height) 
    {
        this.height = height;
    }
    
    
}
